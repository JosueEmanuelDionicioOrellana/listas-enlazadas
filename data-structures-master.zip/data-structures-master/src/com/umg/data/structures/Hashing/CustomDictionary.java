package com.umg.data.structures.Hashing;

import java.util.Enumeration;

public class CustomDictionary<K, V> {
	
	
	
	public int size() {
		return 0;
	}
	
	public boolean isEmpty() {
		return false;
	}
	
	public Enumeration<K> keys() {
		return null;
	}
	
	public Enumeration<V> values() {
		return null;
	}
	
	public V get(K key) {
		return null;
	}
	
	public void put(K key, V value) {
		
	}

	public void remove(K key) {
		
	}
}
